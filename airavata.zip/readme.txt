this is the main major project file
